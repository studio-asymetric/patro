Patro
Enamel sign typeface

Designed by Dalibor Itze, 2022.
Published by Studio Asymetric, 2026.
https://patro.asymetric.studio

License: SIL Open Font License, Version 1.1 (OFL.txt).
Reserved Font Name: Patro.

Version 1.001 (2026) — released under the Open Font License. Drawings unchanged from 1.000.
Version 1.000 (2022) — first complete alphabet, reconstructed from Czechoslovak enamel signs.

Install
- Windows: right-click Patro.ttf and choose Install, or Install for all users.
- macOS: double-click Patro.ttf and choose Install Font.
- Web: use Patro.woff2.

@font-face {
  font-family: "Patro";
  src: url("Patro.woff2") format("woff2");
  font-weight: 700;
  font-style: normal;
  font-display: swap;
}
